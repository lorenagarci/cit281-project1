/*
    CIT 281 Project 1
    Name: Lorena Garcia 
*/

//console.log(new Date().toLocaleString('en-us', {  weekday: 'long' }));

console.log(['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][new Date().getDay()]);